package com.sharing.screen.application;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v4.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.MenuItem;

import com.sharing.screen.R;
import com.sharing.screen.AppController;
import com.sharing.screen.receiver.Remote;
import com.sharing.screen.engine.app.fragments.MonitorScreenFragment;
import com.sharing.screen.engine.app.fragments.ScreenServerFragment;
import com.sharing.screen.engine.app.fragments.ScreenClientFragment;

public class MonitorActivity extends AppCompatActivity {

    public static String TAG = MonitorActivity.class.getSimpleName();
    public final static String ACTION_MONITOR_ACTIVITY = "com.sharing.screen.application.MONITOR_ACTIVITY";
    public final static String ACTION_MONITOR_RECEIVER = "com.sharing.screen.application.MONITOR_RECEIVER";
    public final static String ACTION_MONITOR_PACKAGE_RECEIVER = "com.sharing.screen.application.MONITOR_PACKAGE_RECEIVER";
    public final static String ACTION_MONITOR_SCREEN = "com.sharing.screen.application.MONITOR_SCREEN";
    public final static String ACTION_MONITOR_SDCARD = "com.sharing.screen.application.MONITOR_SDCARD";
    public final static String ACTION_MONITOR_MEMORY = "com.sharing.screen.application.MONITOR_MEMORY";
    public final static String ACTION_MONITOR_LOGGER = "com.sharing.screen.application.MONITOR_LOGGER";
    public final static String EXTRA_TYPE = "EXTRA_TYPE";
    public final static String EXTRA_PATH = "EXTRA_PATH";
    
    public static void start(Context c, String action) {
        Intent mIntent = new Intent(c, MonitorActivity.class);
        mIntent.setAction(action);
        c.startActivity(mIntent);
    }

    public static void startOutPutRecorder(Context c, String path) {
        Intent mIntent = new Intent(c, MonitorActivity.class);
        mIntent.setAction(MonitorActivity.ACTION_MONITOR_SCREEN);
        mIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mIntent.putExtra(EXTRA_TYPE, "SCREEN_RECORD");
        mIntent.putExtra(EXTRA_PATH, path);
        c.startActivity(mIntent);
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_application);

        Toolbar mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);


        String action = getIntent().getAction();
        String subTitle = "";
        if (action != null && action.equals(ACTION_MONITOR_ACTIVITY)) {

            subTitle = "Activity";
          //  switchFragment(new AllTasksListFragment());
        } else if (action != null && action.equals(ACTION_MONITOR_RECEIVER)) {
            subTitle = "Receiver";
          //  switchFragment(MonitorReceiverFragment.newInstance("Monitor Receiver"));
        } else if (action != null && action.equals(ACTION_MONITOR_PACKAGE_RECEIVER)) {
            subTitle = "Package Receiver";
            //  switchFragment(MonitorReceiverFragment.newInstance("Monitor Receiver"));
        } else if (action != null && action.equals(ACTION_MONITOR_SCREEN)) {
            subTitle = "Screen";
            String type = getIntent().getStringExtra(EXTRA_TYPE);
            String path = getIntent().getStringExtra(EXTRA_PATH);
            switchFragment(MonitorScreenFragment.newInstance(type, path));
        } else if (action != null && action.equals(ACTION_MONITOR_SDCARD)) {
            subTitle = "Sdcard";
            switchFragment(new ScreenServerFragment());
        } else if (action != null && action.equals(ACTION_MONITOR_MEMORY)) {
            subTitle = "Memory";
             switchFragment(new ScreenClientFragment());
        } else if (action != null && action.equals(ACTION_MONITOR_LOGGER)) {
            subTitle = "Log";
            switchFragment(ScreenClientFragment.newInstance(AppController.getServerIP()));
        }

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setTitle("Monitor");
            actionBar.setSubtitle(subTitle);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void switchFragment(Fragment fragment) {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.content_frame, fragment)
            .commit();
    }


    @Override
    protected void onResume() {
        super.onResume();
        Log.v(TAG, "onResume:");  
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.v(TAG, "onPause:");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.v(TAG, "onDestroy:");
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Log.v(TAG, "onBackPressed:");
    }
}
