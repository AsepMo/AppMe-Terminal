package com.sharing.screen.application;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v4.app.Fragment;
import android.content.Intent;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.MenuItem;

import com.sharing.screen.R;
import com.sharing.screen.receiver.Remote;
import com.sharing.screen.engine.app.fragments.AppMonitorFragment;

public class ApplicationActivity extends AppCompatActivity {
   
    public static String TAG = ApplicationActivity.class.getSimpleName();
    public static boolean DEBUG = true;
    public static void start(Context c, String action) {
        Intent mIntent = new Intent(c, ApplicationActivity.class);
        mIntent.setAction(action);
        c.startActivity(mIntent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_application);

        Toolbar mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);

        switchFragment(AppMonitorFragment.newInstance(0));
      }
      

    public void switchFragment(Fragment fragment) {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.content_frame, fragment)
            .commit();
    }


    @Override
    protected void onResume() {
        super.onResume();
        Log.v(TAG, "onResume:");  
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.v(TAG, "onPause:");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.v(TAG, "onDestroy:");
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Log.v(TAG, "onBackPressed:");
    }
}
