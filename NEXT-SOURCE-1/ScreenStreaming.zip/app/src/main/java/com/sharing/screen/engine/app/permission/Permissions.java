package com.sharing.screen.engine.app.permission;

public enum Permissions {
    GRANTED,
    DENIED,
    NOT_FOUND
    }

