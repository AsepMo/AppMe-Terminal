package com.sharing.screen.engine.app.listeners;

import com.sharing.screen.receiver.NetworkBroadcastReceiver;

public interface Subject {
    void registerObserver(OnNetworkConnectionChangeListener listener);

    void unregisterObserver(OnNetworkConnectionChangeListener listener);

    void notifyNetworkObserverChange(NetworkBroadcastReceiver.NetworkState networkState);
}


