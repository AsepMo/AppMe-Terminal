package com.sharing.screen.service;

import android.content.Context;

public class ScreenShare
{
	private Context mContext;
    public ScreenShare(Context context)
	{
		this.mContext = context;
	}
}
