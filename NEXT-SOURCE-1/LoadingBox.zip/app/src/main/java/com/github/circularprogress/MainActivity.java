package com.github.circularprogress;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.github.circularprogress.widget.CircleButton;
import com.github.circularprogress.widget.CircularProgressBar;

public class MainActivity extends Activity { 

    private TextView mRequest;
    private CircleButton mIconLoading;
    private CircularProgressBar mProgress;
    private TextView mRoot;
    private Handler mHandler = new Handler();
    private Runnable mRunning = new Runnable()
    {
        @Override
        public void run() {
            mProgress.setVisibility(View.GONE);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mRequest = (TextView)findViewById(R.id.mRequest);
        mRequest.setText("YOU HAVE ROOT?");
        mProgress = (CircularProgressBar) findViewById(R.id.progressBar_1);
        mProgress.setVisibility(View.GONE);
        mIconLoading = (CircleButton) findViewById(R.id.root);
        mIconLoading.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    mProgress.setVisibility(View.VISIBLE);
                    mProgress.setProgress(30f);
                   
                    mHandler.postDelayed(mRunning, 2500);
                    Toast.makeText(MainActivity.this, "Button clicked", Toast.LENGTH_SHORT).show();
                }
        });
        mRoot = (TextView)findViewById(R.id.have_root);
		mRoot.setText("Device : No Root");

        //mHandler.postDelayed(mRunning, 2500);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mHandler.removeCallbacks(mRunning);
    }


}
