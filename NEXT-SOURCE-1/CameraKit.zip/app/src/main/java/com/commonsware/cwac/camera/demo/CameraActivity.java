package com.commonsware.cwac.camera.demo;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import java.io.File;
import com.commonsware.cwac.camera.CameraHost;
import com.commonsware.cwac.camera.CameraHostProvider;
import com.commonsware.cwac.camera.SimpleCameraHost;

public class CameraActivity extends Activity implements CameraHostProvider {
    private CameraFragment current = null;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_camera);
        current = new CameraFragment();

        getFragmentManager().beginTransaction()
            .replace(R.id.container, current).commit();
    }

    @Override
    public CameraHost getCameraHost() {
        return(new SimpleCameraHost(this));
    }
}
