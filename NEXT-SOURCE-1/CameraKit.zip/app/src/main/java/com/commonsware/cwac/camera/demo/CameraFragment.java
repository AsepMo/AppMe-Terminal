package com.commonsware.cwac.camera.demo;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.commonsware.cwac.camera.CameraFragment;
import com.commonsware.cwac.camera.CameraView;

public class CameraFragment extends CameraFragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View content=inflater.inflate(R.layout.view_camera, container, false);
        CameraView cameraView=(CameraView)content.findViewById(R.id.video_preview);

        setCameraView(cameraView);

        return(content);
    }
}
