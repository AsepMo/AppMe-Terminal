package com.commonsware.cwac.camera.listener;

public interface TypeListener {
    void cancel();

    void confirm();
}

