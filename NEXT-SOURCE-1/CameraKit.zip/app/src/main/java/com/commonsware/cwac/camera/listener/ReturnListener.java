package com.commonsware.cwac.camera.listener;

public interface ReturnListener {
    void onReturn();
}

