package com.commonsware.cwac.camera.listener;

public interface SimpleClickListener {
    void onClick();
}

