package com.send.broadcast.engine.app.listeners;

import com.send.broadcast.receivers.NetworkBroadcastReceiver;

public interface Subject {
    void registerObserver(OnNetworkConnectionChangeListener listener);

    void unregisterObserver(OnNetworkConnectionChangeListener listener);

    void notifyNetworkObserverChange(NetworkBroadcastReceiver.NetworkState networkState);
}

