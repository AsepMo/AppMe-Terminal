package com.send.broadcast.application;

import android.Manifest;
import android.support.annotation.Nullable;
import android.support.annotation.NonNull;
import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.view.Gravity;
import android.widget.Toast;

import java.io.File;
import java.util.List;
import java.util.ArrayList;

import com.send.broadcast.R;
import com.send.broadcast.AppController;

public class Application {

    private static final String TAG = Application.class.getSimpleName();
    private static volatile Application Instance = null;
    private Context context;

    public static Application getInstance() {
        Application localInstance = Instance;
        if (localInstance == null) {
            synchronized (Application.class) {
                localInstance = Instance;
                if (localInstance == null) {
                    Instance = localInstance = new Application(AppController.getContext());
                }
            }
        }
        return localInstance;
    }

    private Application(Context context) {
        this.context = context;
    }

    public static Application with(Context context) {
        return new Application(context);
    }

    public void setOnApplicationTaskListener(final Activity act, final OnApplicationTaskListener listener) {

    }

    public interface OnActionPermissionListener {
        void onGranted();
        void onDenied(String permission);
    }

    public interface OnApplicationTaskListener {
        void onPreExecute();
        void onSuccess(List<String> result);
        void onFailed();
        void isEmpty();
    }
}

