package com.send.broadcast;

import com.send.broadcast.application.SendBroadcastApplication;

public class AppController extends SendBroadcastApplication {
    private static AppController isInstance;

    @Override
    public void onCreate() {
        super.onCreate();
        
        isInstance = this;
    }

    @Override
    public void initAnalytics() {
        super.initAnalytics();
    }

    @Override
    public void initCrashHandler() {
        super.initCrashHandler();
    }

    @Override
    public void initLogger() {
        super.initLogger();
    }

    @Override
    public void initFolder() {
        super.initFolder();
    }
    
    public static synchronized AppController getInstance() {
        return isInstance;
    }

    
}
