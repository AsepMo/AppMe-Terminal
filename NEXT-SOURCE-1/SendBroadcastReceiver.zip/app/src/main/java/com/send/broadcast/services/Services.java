package com.send.broadcast.services;

import android.content.Context;
import android.content.Intent;

import com.send.broadcast.SendBroadcast;
import com.send.broadcast.AppController;
import com.send.broadcast.BroadcastActivity;

public class Services {
    private static volatile Services Instance = null;
    private Context context;

    public static Services getInstance() {
        Services localInstance = Instance;
        if (localInstance == null) {
            synchronized (Services.class) {
                localInstance = Instance;
                if (localInstance == null) {
                    Instance = localInstance = new Services(AppController.getContext());
                }
            }
        }
        return localInstance;
    }

    private Services(Context context) {
        this.context = context;
    }

    public static Services with(Context context) {
        return new Services(context);
    }
    
    public void launchRecordingService() {
        SendBroadcast.killAllProcessorServices(context);
        Intent mServiceIntent = new Intent(context, SendBroadcastService.class);
        mServiceIntent.setAction(SendBroadcast.ACTION.LAUNCH_SERVICE);
        context.startService(mServiceIntent);
    }

    public void startRecordingService() {
        if (SendBroadcast.isProcessorServiceRunning(context)) {
            Intent mServiceIntent = new Intent(context, SendBroadcastService.class);
            mServiceIntent.setAction(SendBroadcast.ACTION.START_RECORDING);
            context.startService(mServiceIntent);
        }
    }

    public void pauseRecordingService() {
        if (SendBroadcast.isProcessorServiceRunning(context)) {
            Intent mServiceIntent = new Intent(context, SendBroadcastService.class);
            mServiceIntent.setAction(SendBroadcast.ACTION.PAUSE_RECORDING);
            context.startService(mServiceIntent);
        }
    }

    public void resumeRecordingService() {
        if (SendBroadcast.isProcessorServiceRunning(context)) {
            Intent mServiceIntent = new Intent(context, SendBroadcastService.class);
            mServiceIntent.setAction(SendBroadcast.ACTION.RESUME_RECORDING);
            context.startService(mServiceIntent);
        }
    }

    public void stopRecordingService() {
        if (SendBroadcast.isProcessorServiceRunning(context)) {
            Intent mServiceIntent = new Intent(context, SendBroadcastService.class);
            mServiceIntent.setAction(SendBroadcast.ACTION.STOP_RECORDING);
            context.startService(mServiceIntent);
        }
    }

    public void finishRecordingService() {
        if (SendBroadcast.isProcessorServiceRunning(context)) {
            Intent mServiceIntent = new Intent(context, SendBroadcastService.class);
            mServiceIntent.setAction(SendBroadcast.ACTION.FINISH_RECORDING);
            context.startService(mServiceIntent);
        }
    }

    public void doneRecordingService() {
        if (SendBroadcast.isProcessorServiceRunning(context)) {
            Intent mServiceIntent = new Intent(context, SendBroadcastService.class);
            mServiceIntent.setAction(SendBroadcast.ACTION.DONE_RECORDING);       
            mServiceIntent.putExtra(SendBroadcast.START_ACTIVITY, SendBroadcastService.getOutPut(context));
            context.startService(mServiceIntent);
        }
    }


    public void shutdownRecordingService() {
        if (SendBroadcast.isProcessorServiceRunning(context)) {
            Intent mServiceIntent = new Intent(context, SendBroadcastService.class);
            mServiceIntent.setAction(SendBroadcast.ACTION.SHUTDOWN_SERVICE);
            context.startService(mServiceIntent);
        }
    }
    
}
