package com.send.broadcast.receivers;

import android.content.Context;
import android.content.Intent;
import android.content.BroadcastReceiver;

import com.send.broadcast.SendBroadcast;

public class SendBroadcastReceiver extends BroadcastReceiver {

    public static String TAG = SendBroadcastReceiver.class.getSimpleName();

    private OnSendBroadcastListener listener;
    public interface OnSendBroadcastListener {
        void onServiceReady(String message);
        void onStart(String message);
        void onPause(String message);
        void onResume(String message);  
        void onFinish(String message);
        void onStartActivity(String message);
        void onError(String message);
        void onStop(String message);
        void onDone(String message);
        void onServiceShutDown(String message);
    }

    public void setOnSendBroadcastListener(OnSendBroadcastListener listener) {
        this.listener = listener;
    }

    @Override
    public void onReceive(Context pContext, Intent pIntent) {
        String statusKey = "";
        String statusData = "";
        if (pIntent.hasExtra(SendBroadcast.PROCESS_STATUS_KEY)) {
            statusKey = pIntent.getStringExtra(SendBroadcast.PROCESS_STATUS_KEY);
        }
        if (pIntent.hasExtra(SendBroadcast.PROCESS_STATUS_MESSAGE)) {
            statusData = pIntent.getStringExtra(SendBroadcast.PROCESS_STATUS_MESSAGE);
        }
        switch (statusKey) {
            case SendBroadcast.SERVICE_IS_READY:
                listener.onServiceReady(statusData);
                break;
            case SendBroadcast.START_RECORDING:
                listener.onStart(statusData);
                break;
            case SendBroadcast.STOP_RECORDING:
                listener.onStop(statusData);
                break; 
            case SendBroadcast.PAUSE_RECORDING:
                listener.onPause(statusData);
                break;      
            case SendBroadcast.FINISH_RECORDING:
                listener.onFinish(statusData);
                break;
            case SendBroadcast.RESUME_RECORDING:
                listener.onResume(statusData);
                break;     
            case SendBroadcast.START_ACTIVITY:
                listener.onStartActivity(statusData);
                break;
            case SendBroadcast.START_ACTIVITY_WITH_ERROR:
                listener.onStartActivity(statusData);
                break;  
            case SendBroadcast.EXIT_RECORDING_ON_ERROR:
                listener.onError(statusData);
                break;  
            case SendBroadcast.RECORDING_IS_DONE:
                listener.onDone(statusData);
                break;  
            case SendBroadcast.SERVICE_IS_SHUTDOWN:
                listener.onServiceShutDown(statusData);
                break;  

        }

    }

}

