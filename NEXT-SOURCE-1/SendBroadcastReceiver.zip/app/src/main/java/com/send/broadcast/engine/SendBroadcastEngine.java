package com.send.broadcast.engine;

public class SendBroadcastEngine {
    
    public static String TAG = SendBroadcastEngine.class.getSimpleName();
    
}