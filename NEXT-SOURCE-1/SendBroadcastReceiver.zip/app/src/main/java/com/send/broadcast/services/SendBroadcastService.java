package com.send.broadcast.services;

import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.preference.PreferenceManager;
import android.widget.Toast;

import java.io.File;

import com.send.broadcast.R;
import com.send.broadcast.SendBroadcast;
import com.send.broadcast.BroadcastActivity;
import com.send.broadcast.engine.app.notification.Notify;

@SuppressWarnings({"ConstantConditions", "ResultOfMethodCallIgnored"})
public class SendBroadcastService extends Service {

    public static String TAG = SendBroadcastService.class.getSimpleName();
    public Handler UIHandler;

    public Notify processNotify;

    public String mFileName;
    public String mFilePath;

    public String recording;

    public static String getOutPut(Context ctx) {
        return Environment.getExternalStorageDirectory() + File.separator + ctx.getString(R.string.app_name);     
    }

    private boolean showRecord = false;
    private boolean recordOnNextStart = false;

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);

        /**
         * Initialize a handler for posting runnables that have to run on the UI thread
         */
        UIHandler = new Handler();

        /**
         * Receive action from the intent and decide whether to start or stop the existing process
         */
        if (intent.getAction().equals(SendBroadcast.ACTION.LAUNCH_SERVICE)) {

            mFilePath = getOutPut(getApplicationContext());
            File file = new File(mFilePath);
            if (!file.exists()) {
                file.mkdirs();
            }
            UIHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        broadcastStatus(SendBroadcast.SERVICE_IS_READY, "Service Is Launching");                                 
                    }
                });
            if (recordOnNextStart) {
                startRecorder();
            }

            startForeground(SendBroadcast.PROCESS_NOTIFICATION_ID, buildNotify());

            recordOnNextStart = false;
        } else if (intent.getAction().equals(SendBroadcast.ACTION.START_RECORDING)) {        
            broadcastStatus(SendBroadcast.START_RECORDING, "Recording Is Started"); 

            recordOnNextStart = false;  
        } else if (intent.getAction().equals(SendBroadcast.ACTION.PAUSE_RECORDING)) {
            broadcastStatus(SendBroadcast.PAUSE_RECORDING, "Recording Is Paused"); 


            recordOnNextStart = true;         
        } else if (intent.getAction().equals(SendBroadcast.ACTION.RESUME_RECORDING)) {
            broadcastStatus(SendBroadcast.RESUME_RECORDING, "Recording Is Resumed");  


            recordOnNextStart = false;           
        } else if (intent.getAction().equals(SendBroadcast.ACTION.STOP_RECORDING)) {
            broadcastStatus(SendBroadcast.STOP_RECORDING, "Recording Is Stopped");          

            recordOnNextStart = true;    
        } else if (intent.getAction().equals(SendBroadcast.ACTION.FINISH_RECORDING)) {
            broadcastStatus(SendBroadcast.FINISH_RECORDING, "Recording Is Finished");   
            
        } else if (intent.getAction().equals(SendBroadcast.ACTION.DONE_RECORDING)) {
            broadcastStatus(SendBroadcast.RECORDING_IS_DONE, "Recording Is Done");
            Bundle extras = intent.getExtras();
            if (extras != null) {

                if (extras.containsKey(SendBroadcast.START_ACTIVITY)) {
                    mFilePath = extras.getString(SendBroadcast.START_ACTIVITY);
                }


                UIHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            publishProgress(SendBroadcast.START_ACTIVITY);                                 
                        }
                    });
            } else {
                killSelf();
            }
            
        } else if (intent.getAction().equals(SendBroadcast.ACTION.SHUTDOWN_SERVICE)) {
            broadcastStatus(SendBroadcast.SERVICE_IS_SHUTDOWN, "Service Is Shutdown");                  
            
            UIHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        killSelf();                      
                    }
                }, 1200);
        }
        return START_NOT_STICKY;
    }

    public void startRecorder() {
        
    }

    public void publishProgress(String progressText) {
        switch (progressText) {
            case SendBroadcast.START_RECORDING : {

                    break;
                }
            case SendBroadcast.START_ACTIVITY : {
                    decompileDone();
                    broadcastStatus(progressText, mFilePath);
                    killSelf();
                    break;
                }
            case SendBroadcast.START_ACTIVITY_WITH_ERROR: {
                    decompileDone();
                    broadcastStatus(progressText, mFilePath);
                    UIHandler.post(new ToastRunnable("Decompilation completed with errors. This incident has been reported to the developer."));
                    kill();
                    break;
                }
            case SendBroadcast.EXIT_RECORDING_ON_ERROR:
                broadcastStatus(progressText);
                UIHandler.post(new ToastRunnable("The app you selected cannot be decompiled. Please select another app."));
                kill();
                break;
            default:
                break;
        }
    }

    private void decompileDone() {
        showCompletedNotification();
    }

    private void showCompletedNotification() {

        Intent resultIntent = new Intent(getApplicationContext(), BroadcastActivity.class);     
        PendingIntent resultPendingIntent = PendingIntent.getActivity(SendBroadcastService.this, 0, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationManager mNotifyManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this);
        mBuilder.setContentTitle(" Recording Success.")
            .setContentText("Tap to Playing")
            .setSmallIcon(R.drawable.ic_launcher)
            .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher))
            .setContentIntent(resultPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true);

        mNotifyManager.notify(2, mBuilder.build());
    }

    public void broadcastStatus(String status) {
        sendNotification(status, "");
        Intent localIntent = new Intent(SendBroadcast.PROCESS_BROADCAST_ACTION)
            .putExtra(SendBroadcast.PROCESS_STATUS_KEY, status);
        sendBroadcast(localIntent);
    }

    public void broadcastStatus(String statusKey, String statusData) {
        sendNotification(statusKey, statusData);
        Intent localIntent = new Intent(SendBroadcast.PROCESS_BROADCAST_ACTION)
            .putExtra(SendBroadcast.PROCESS_STATUS_KEY, statusKey)
            .putExtra(SendBroadcast.PROCESS_STATUS_MESSAGE, statusData);
        sendBroadcast(localIntent);
    }

    private void sendNotification(String statusKey, String statusData) {
        switch (statusKey) {
            case SendBroadcast.SERVICE_IS_READY:
                processNotify.updateTitleText("Screen Record", "Recording Service Is Ready ...");
                break;
            case SendBroadcast.START_RECORDING:
                processNotify.updateTitleText("Screen Record", "Recording Is Started");
                break;
            case SendBroadcast.PAUSE_RECORDING:
                processNotify.updateTitleText("Screen Record", "Recording Is Paused");
                break;   
            case SendBroadcast.RESUME_RECORDING:
                processNotify.updateTitleText("Screen Record", "Recording Is Resumed");
                break;  
            case SendBroadcast.RECORDING_IS_DONE:
                processNotify.updateTitleText("Screen Record", "Recording Is Done");
                break;    
            case SendBroadcast.FINISH_RECORDING:
                processNotify.updateTitleText("Finishing Recording", "Recording Is Finish");
                break;
            case SendBroadcast.SERVICE_IS_SHUTDOWN:
                processNotify.updateTitleText("Service Shutdown", "Recording Service Is Shutdown");            
                break;
            case SendBroadcast.START_ACTIVITY:
                processNotify.cancel();
                break;
            case SendBroadcast.START_ACTIVITY_WITH_ERROR:
                processNotify.cancel();
                break;
            case SendBroadcast.EXIT_RECORDING_ON_ERROR:
                processNotify.cancel();
                break;          
            case SendBroadcast.RECORDING_IS_DONE:
                try {
                    processNotify.cancel();
                } catch (Exception e) {
                    Log.i(TAG, e.getMessage());
                }
                break;

            default:
                processNotify.updateText(statusData);
        }
    }

    private Notification buildNotify() {
        NotificationManager mNotifyManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this);
        mBuilder.setContentTitle("Screen Recorder");
        mBuilder.setContentText("Recording..");
        mBuilder.setSmallIcon(R.drawable.ic_launcher);
        mBuilder.setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher));
        mBuilder.setOngoing(true);
        mBuilder.addAction(R.drawable.ic_transfer_down, "Shutdown", buildPendingIntent(SendBroadcast.ACTION.SHUTDOWN_SERVICE));
        
        mBuilder.setAutoCancel(false);        
        Notification notification = mBuilder.build();

        mNotifyManager.notify(SendBroadcast.PROCESS_NOTIFICATION_ID, notification);
        processNotify = new Notify(mNotifyManager, mBuilder, SendBroadcast.PROCESS_NOTIFICATION_ID);

        return notification;
    }

    private PendingIntent buildPendingIntent(String action) {
        Intent i = new Intent(this, getClass());
        i.setAction(action);
        return(PendingIntent.getService(this, 0, i, 0));
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            kill();
            processNotify.cancel();
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public void kill() {
        stopForeground(true);
        stopSelf();
    }

    private class ToastRunnable implements Runnable {

        String mText;

        public ToastRunnable(String text) {
            mText = text;
        }

        @Override
        public void run() {
            Toast.makeText(getApplicationContext(), mText, Toast.LENGTH_SHORT).show();
        }
    }

    private void killSelf() {
        stopForeground(true);
        try {
            NotificationManager mNotifyManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            mNotifyManager.cancel(SendBroadcast.PROCESS_NOTIFICATION_ID);
            SendBroadcast.killAllProcessorServices(this);
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
        stopSelf();
    }
}

