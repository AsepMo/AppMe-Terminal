package com.send.broadcast;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v4.content.ContextCompat;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.send.broadcast.receivers.SendBroadcastLogger;
import com.send.broadcast.receivers.SendBroadcastReceiver;
import com.send.broadcast.engine.app.network.AutoRefreshNetworkUtil;
import com.send.broadcast.engine.app.network.CheckNetworkConnectionHelper;
import com.send.broadcast.engine.app.listeners.OnNetworkConnectionChangeListener;
import com.send.broadcast.engine.app.utils.Global;
import com.send.broadcast.engine.widget.ScreenRecording;
import com.send.broadcast.services.Services;

public class BroadcastActivity extends AppCompatActivity implements SendBroadcastReceiver.OnSendBroadcastListener {

    public static String TAG = BroadcastActivity.class.getSimpleName();
    private static final String SENDBROADCAST_PACKAGE_NAME = "com.send.broadcast";
    private ScreenRecording CurrentStatus;
    private SendBroadcastReceiver processStatusReceiver;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_broadcast);
		
		Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
        
        CurrentStatus = (ScreenRecording) findViewById(R.id.status);

        setRecordStatus("Screen Recorder", "Record Your Screen Now!");
        if (SendBroadcast.isProcessorServiceRunning(this)) {

            if (!fromNotification()) {
                Services.with(this).startRecordingService();
            } else {
                setRecordStatus("Screen Recorder", "Recording..");
            }
        }else{     
            Services.with(this).launchRecordingService();
        }
        processStatusReceiver = new SendBroadcastReceiver();
        processStatusReceiver.setOnSendBroadcastListener(this);
        SendBroadcastLogger.sendBroadcast(this, "SendBroadcast Initialized");
        if (!Global.isPackageInstalled(BroadcastActivity.this, SENDBROADCAST_PACKAGE_NAME)) {
            SendBroadcastLogger.sendBroadcast(this, "SendBroadcaster not installed");
            return;
        }
        
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerBroadcastReceiver();
        CheckNetworkConnectionHelper
            .getInstance()
            .registerNetworkChangeListener(new OnNetworkConnectionChangeListener() {
                @Override
                public void onDisconnected() {
                    //Do your task on Network Disconnected!
                    Log.e(TAG, "onDisconnected");
                    Toast.makeText(BroadcastActivity.this, "Network Disconnected!", Toast.LENGTH_SHORT).show();
                    
               }

                @Override
                public void onConnected() {
                    //Do your task on Network Connected!
                    Log.e(TAG, "onConnected");
                    Toast.makeText(BroadcastActivity.this, "Network Connected!", Toast.LENGTH_SHORT).show();                 
                }

                @Override
                public Context getContext() {
                    return BroadcastActivity.this;
                }
            });
    }
    
    @Override
    public void onServiceReady(String message) {
        setRecordStatus("Screen Recorder", message);
        SendBroadcastLogger.sendBroadcast(this, message);   
    }

    @Override
    public void onStart(String message) {
        setRecordStatus("Screen Recorder", "Start Recording");
        SendBroadcastLogger.sendBroadcast(this, message);  
    }

    @Override
    public void onPause(String message) {
        setRecordStatus("Screen Recorder", message);
        SendBroadcastLogger.sendBroadcast(this, message);  
    }

    @Override
    public void onResume(String message) {
        setRecordStatus("Screen Recorder", message);
        SendBroadcastLogger.sendBroadcast(this, message);  
    }

    @Override
    public void onFinish(String message) {
        setRecordStatus("Screen Recorder", message);
        SendBroadcastLogger.sendBroadcast(this, message);  
    }

    @Override
    public void onStartActivity(String message) {
        setRecordStatus("Screen Recorder", message);
        SendBroadcastLogger.sendBroadcast(this, message);  
    }

    @Override
    public void onError(String message) {
        setRecordStatus("Screen Recorder", message);
        SendBroadcastLogger.sendBroadcast(this, message);  
    }

    @Override
    public void onStop(String message) {
        setRecordStatus("Screen Recorder", message);
        SendBroadcastLogger.sendBroadcast(this, message);  
    }

    @Override
    public void onDone(String message) {
        setRecordStatus("Screen Recorder", message);
        SendBroadcastLogger.sendBroadcast(this, message); 
    }

    @Override
    public void onServiceShutDown(String message) {
        setRecordStatus("Screen Recorder", message);
        SendBroadcastLogger.sendBroadcast(this, message);  
    }

    public void setRecordStatus(String currentStatus, String currentLine) {
        CurrentStatus.setCurrentStatus(currentStatus);
        CurrentStatus.setCurrentLine(currentLine);
        CurrentStatus.setStatus(ScreenRecording.Status.COMPLETE);
    }

    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_recordings, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_launch:
                Services.with(this).launchRecordingService();
                break;
            case R.id.action_start:
                Services.with(this).startRecordingService();
                break;
            case R.id.action_pause:
                Services.with(this).pauseRecordingService();
                break;  
            case R.id.action_resume:
                Services.with(this).resumeRecordingService();
                break;
            case R.id.action_stop:
                Services.with(this).stopRecordingService();
                break;
            case R.id.action_finish:
                Services.with(this).finishRecordingService();
                break;
            case R.id.action_done:
                Services.with(this).doneRecordingService();
                break;    
            case R.id.action_shutdown:
                Services.with(this).shutdownRecordingService();
                break;     

        }
        return super.onOptionsItemSelected(item);
    }

    
    public void registerBroadcastReceiver() {
        IntentFilter statusIntentFilter = new IntentFilter(SendBroadcast.PROCESS_BROADCAST_ACTION);
        registerReceiver(processStatusReceiver, statusIntentFilter);
    }

    @SuppressWarnings("unused")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                String result = data.getStringExtra("result");
                finish();
            }
            if (resultCode == RESULT_CANCELED) {
                finish();
            } else {
                moveTaskToBack(true);
            }
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        }
    }

    private boolean fromNotification() {
        return getIntent().hasExtra("from_notification") && getIntent().getBooleanExtra("from_notification", false);
    }


    @Override
    protected void onPause() {
        super.onPause();
        
    }

    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(processStatusReceiver);
        AutoRefreshNetworkUtil.onDestroy();
    }

}
