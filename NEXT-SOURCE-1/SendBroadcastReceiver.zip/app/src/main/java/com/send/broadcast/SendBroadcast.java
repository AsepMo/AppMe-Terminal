package com.send.broadcast;

import android.app.ActivityManager;
import android.content.Context;

import java.io.File;
import java.util.List;

public class SendBroadcast {
    public static String TAG = SendBroadcast.class.getSimpleName();
    
    public static final String BASE = "com.send.broadcast.process";
    public static final String PROCESS_BROADCAST_ACTION = BASE + ".BROADCAST";
    public static final String PROCESS_STATUS_KEY = BASE +".STATUS_KEY";
    public static final String PROCESS_STATUS_MESSAGE = BASE + ".STATUS_MESSAGE";
    public static final String PROCESS_DIR = BASE + ".DIR";
    public static final String EXTRA_FILE_PATH = "FILE_PATH";
    public static final String EXTRA_FILE_NAME = "FILE_PATH";
    public static final String RECORDING_VIDEO_ID = BASE +".VIDEO_ID";
    public static final int PROCESS_NOTIFICATION_ID = 1;

    public static final String SERVICE_IS_READY = "SERVICE_IS_READY";
    public static final String START_RECORDING = "START_RECORDING";
    public static final String START_ACTIVITY = "START_ACTIVITY";
    public static final String PAUSE_RECORDING = "PAUSE_RECORDING";
    public static final String RESUME_RECORDING = "RESUME_RECORDING";
    public static final String STOP_RECORDING = "STOP_RECORDING";
    public static final String START_ACTIVITY_WITH_ERROR = "START_ACTIVITY_WITH_ERROR";
    public static final String EXIT_RECORDING_ON_ERROR = "EXIT_RECORDING_ON_ERROR";
    public static final String FINISH_RECORDING = "FINISH_RECORDING";
    public static final String RECORDING_IS_DONE = "RECORDING_IS_DONE";
    public static final String SERVICE_IS_SHUTDOWN = "SERVICE_IS_SHUTDOWN";

    public interface ACTION {
        String LAUNCH_SERVICE = BASE + ".action.LAUNCH_SERVICE";      
        String START_RECORDING = BASE + ".action.START_RECORDING";
        String PAUSE_RECORDING = BASE + ".action.PAUSE_RECORDING";
        String RESUME_RECORDING = BASE + ".action.RESUME_RECORDING";
        String STOP_RECORDING = BASE + ".action.STOP_RECORDING";
        String DONE_RECORDING = BASE + ".action.RECORDING_DONE";
        String FINISH_RECORDING = BASE + ".action.FINISH_RECORDING";
        String SHUTDOWN_SERVICE = BASE + ".action.SHUTDOWN_SERVICE";
    }

    public static void killAllProcessorServices(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> runningAppProcesses = am.getRunningAppProcesses();
        for (ActivityManager.RunningAppProcessInfo next : runningAppProcesses) {
            String processName = context.getPackageName() + ":service";
            if (next.processName.equals(processName)) {
                android.os.Process.killProcess(next.pid);
                break;
            }
        }
    }

    public static boolean isProcessorServiceRunning(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> runningAppProcesses = am.getRunningAppProcesses();
        for (ActivityManager.RunningAppProcessInfo next : runningAppProcesses) {
            String processName = context.getPackageName() + ":service";
            if (next.processName.equals(processName)) {
                return true;
            }
        }
        return false;
    }

}

