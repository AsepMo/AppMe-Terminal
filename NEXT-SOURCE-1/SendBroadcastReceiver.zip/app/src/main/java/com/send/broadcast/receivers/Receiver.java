package com.send.broadcast.receivers;

public class Receiver {
   
}
