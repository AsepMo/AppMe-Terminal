package com.send.broadcast.engine;

public class Engine {
    public static String TAG = Engine.class.getSimpleName();
    
}
