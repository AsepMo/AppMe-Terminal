package com.apps.monitor.application;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v4.app.Fragment;
import android.os.Bundle;

import com.apps.monitor.R;
import com.apps.monitor.engine.app.fragments.AppMonitorFragment;

public class ApplicationActivity extends AppCompatActivity {

    public static String TAG = ApplicationActivity.class.getSimpleName();
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme_NoActionBar);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_application);

        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        switchFragment(AppMonitorFragment.newInstance(""));
    }


    public void switchFragment(Fragment fragment){
        getSupportFragmentManager()
        .beginTransaction()
        .replace(R.id.content_frame, fragment)
        .commit();      
    }
}
