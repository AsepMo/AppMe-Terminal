package com.apps.monitor.engine.app.base;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;

import com.apps.monitor.engine.app.utils.T;


@SuppressLint("NewApi")
public class BaseFragment extends Fragment {

    /** Class **/
    protected void startActivity(Class<?> cls) {
        startActivity(cls, null);
    }

    /** Bundle Class **/
    protected void startActivity(Class<?> cls, Bundle bundle) {
        Intent intent = new Intent();
        intent.setClass(getActivity(), cls);
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        startActivity(intent);
    }

    /** Action **/
    protected void startActivity(String action) {
        startActivity(action, null);
    }

    /** Bundle Action **/
    protected void startActivity(String action, Bundle bundle) {
        Intent intent = new Intent();
        intent.setAction(action);
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        startActivity(intent);
    }

    /**
     * 吐司
     * 
     * @param message
     */
    protected void showShort(String message) {
        T.showShort(getActivity(), message);
    }

    protected void showLong(String message) {
        T.showLong(getActivity(), message);
    }
}


