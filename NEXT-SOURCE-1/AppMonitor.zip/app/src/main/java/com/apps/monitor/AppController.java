package com.apps.monitor;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.graphics.Point;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.support.annotation.Nullable;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Locale;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.LinkedTransferQueue;


import com.apps.monitor.application.ApplicationSettings;

public class AppController extends Application {

    private static AppController isInstance;
    private static Context mContext;
    
    private ApplicationSettings applicationSettings;
    
    
    private volatile boolean isServerRunning;
    private volatile boolean isRecorderRunning;
    private volatile int webServerPort;
    private volatile int wsServerPort;
    private volatile int serverConnCount;
    private volatile String localIp;
    
    @Override
    public void onCreate() {
        super.onCreate();
        
        isInstance = this;
        mContext = this;
        setWebServerPort(8123);
        setWsServerPort(8012);
        setServerConnCount(0);
        
    }
    
    public static synchronized AppController getInstance() {
        return isInstance;
    }

    public static Context getContext() {
        return mContext;
    }
    
    public static boolean isServerRunning() {
        return isInstance.isServerRunning;
    }

    public static void setIsServerRunning(final boolean isRunning) {
        isInstance.isServerRunning = isRunning;
    }

    public static boolean isRecorderRunning() {
        return isInstance.isRecorderRunning;
    }

    public static void setIsRecordingRunning(final boolean isRunning) {
        isInstance.isRecorderRunning = isRunning;
    }

    public static void setLocalIp(final String port) {
        isInstance.localIp = port;
    }

    public static String getLocalIp()
    {
        return isInstance.localIp;
    }

    public static void setWebServerPort(final int port) {
        isInstance.webServerPort = port;
    }

    public static int getWebServerPort()
    {
        return isInstance.webServerPort;
    }

    public static void setWsServerPort(final int port) {
        isInstance.wsServerPort = port;
    }

    public static int getWsServerPort()
    {
        return isInstance.wsServerPort;
    }

    public static void setServerConnCount(final int port) {
        isInstance.serverConnCount = port;
    }

    public static int getServerConnCount()
    {
        return isInstance.serverConnCount;
    }

    public static String getServerAddress() {
        return "http://" + isInstance.getIPAddress() + ":" + isInstance.applicationSettings.getSeverPort();
    }

    public static boolean isWiFIConnected() {
        final WifiManager wifi = (WifiManager) isInstance.getSystemService(Context.WIFI_SERVICE);
        return wifi.getConnectionInfo().getNetworkId() != -1;
    }

    // Private methods
    private String getIPAddress() {
        final int ipInt = ((WifiManager) getSystemService(Context.WIFI_SERVICE)).getConnectionInfo().getIpAddress();
        return String.format(Locale.US, "%d.%d.%d.%d", (ipInt & 0xff), (ipInt >> 8 & 0xff), (ipInt >> 16 & 0xff), (ipInt >> 24 & 0xff));
    }
    
}


