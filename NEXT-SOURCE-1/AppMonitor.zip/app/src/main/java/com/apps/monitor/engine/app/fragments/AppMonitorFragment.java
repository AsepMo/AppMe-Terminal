package com.apps.monitor.engine.app.fragments;

import android.support.annotation.Nullable;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Gravity;
import android.widget.Toast;

import com.apps.monitor.R;
import com.apps.monitor.engine.app.base.BaseFragment;
import com.apps.monitor.engine.app.monitor.MonitorLayout;
import com.apps.monitor.engine.app.monitor.MonitorElement;

public class AppMonitorFragment extends BaseFragment {

    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_POSITION = "position";
    private static final String TAG = AppMonitorFragment.class.getSimpleName();

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment Record_Fragment.
     */
    public static AppMonitorFragment newInstance(String message) {
        AppMonitorFragment f = new AppMonitorFragment();
        Bundle b = new Bundle();
        b.putString(ARG_POSITION, message);
        f.setArguments(b);

        return f;
    }

    public AppMonitorFragment() {
    }

    private String message; // 0:，2 
    private MonitorLayout mMonitor;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        message = getArguments().getString(ARG_POSITION);
    }

    @Override
    public View onCreateView(LayoutInflater inflater,  @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // TODO Auto-generated method stub

        return inflater.inflate(R.layout.fragment_app_monitor, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mMonitor = (MonitorLayout)view.findViewById(R.id.app_monitor);

    }

    @Override
    public void onResume() {
        super.onResume();
        
    }


    @Override
    public void onPause() {
        super.onPause();
        
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        
    }
}

