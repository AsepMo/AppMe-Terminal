package com.apps.monitor.application;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v4.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.MenuItem;

import com.apps.monitor.R;
import com.apps.monitor.receiver.SendBroadcast;

public class MonitorActivity extends AppCompatActivity {

    public static String TAG = MonitorActivity.class.getSimpleName();
    public final static String ACTION_MONITOR_ACTIVITY = "com.apps.monitor.application.MONITOR_ACTIVITY";
    public final static String ACTION_MONITOR_RECEIVER = "com.apps.monitor.application.MONITOR_RECEIVER";
    public final static String ACTION_MONITOR_PACKAGE_RECEIVER = "com.apps.monitor.application.MONITOR_PACKAGE_RECEIVER";
    public final static String ACTION_MONITOR_SCREEN = "com.apps.monitor.application.MONITOR_SCREEN";
    public final static String ACTION_MONITOR_SDCARD = "com.apps.monitor.application.MONITOR_SDCARD";
    public final static String ACTION_MONITOR_MEMORY = "com.apps.monitor.application.MONITOR_MEMORY";
    public final static String ACTION_MONITOR_LOGGER = "com.apps.monitor.application.MONITOR_LOGGER";
    public final static String EXTRA_TYPE = "EXTRA_TYPE";
    public final static String EXTRA_PATH = "EXTRA_PATH";

    public static void start(Context c, String action) {
        Intent mIntent = new Intent(c, MonitorActivity.class);
        mIntent.setAction(action);
        c.startActivity(mIntent);
    }

    public static void startOutPutRecorder(Context c, String path) {
        Intent mIntent = new Intent(c, MonitorActivity.class);
        mIntent.setAction(MonitorActivity.ACTION_MONITOR_SCREEN);
        mIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mIntent.putExtra(MonitorActivity.EXTRA_TYPE, SendBroadcast.TYPE.SCREEN_RECORD);
        mIntent.putExtra(MonitorActivity.EXTRA_TYPE, path);
        c.startActivity(mIntent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_application);

        Toolbar mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);


        String action = getIntent().getAction();
        String subTitle = "";
        if (action != null && action.equals(ACTION_MONITOR_ACTIVITY)) {

            subTitle = "Activity";
            //switchFragment(new AllTasksListFragment());
        } else if (action != null && action.equals(ACTION_MONITOR_RECEIVER)) {
            subTitle = "Receiver";
            //switchFragment(MonitorReceiverFragment.newInstance("Monitor Receiver"));
        } else if (action != null && action.equals(ACTION_MONITOR_PACKAGE_RECEIVER)) {
            subTitle = "Package Receiver";
            //  switchFragment(MonitorReceiverFragment.newInstance("Monitor Receiver"));
        } else if (action != null && action.equals(ACTION_MONITOR_SCREEN)) {
            subTitle = "Screen";
            String type = getIntent().getStringExtra(EXTRA_TYPE);
            String path = getIntent().getStringExtra(EXTRA_PATH);
            //switchFragment(MonitorScreenFragment.newInstance(type, path));
        } else if (action != null && action.equals(ACTION_MONITOR_SDCARD)) {
            subTitle = "Sdcard";
            //  switchFragment(MonitorReceiverFragment.newInstance("Monitor Receiver"));
        } else if (action != null && action.equals(ACTION_MONITOR_MEMORY)) {
            subTitle = "Memory";
            //  switchFragment(MonitorReceiverFragment.newInstance("Monitor Receiver"));
        } else if (action != null && action.equals(ACTION_MONITOR_LOGGER)) {
            subTitle = "Log";
            //  switchFragment(MonitorReceiverFragment.newInstance("Monitor Receiver"));
        }

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setTitle("Monitor");
            actionBar.setSubtitle(subTitle);
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void switchFragment(Fragment fragment) {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.content_frame, fragment)
            .commit();
    }


    @Override
    protected void onResume() {
        super.onResume();
        Log.v(TAG, "onResume:");  
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.v(TAG, "onPause:");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.v(TAG, "onDestroy:");
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Log.v(TAG, "onBackPressed:");
    }
}

