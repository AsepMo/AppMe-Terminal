package com.lukegryga.smileup.adapters;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.lukegryga.smileup.EmojiManager;
import com.lukegryga.smileup.R;
import com.lukegryga.smileup.components.EmojiViewGroup;

import java.io.Serializable;

public class StoryAdapter extends BaseAdapter implements Parcelable{

    private Integer[] emojiIds = new Integer[EmojiManager.MAX_EMOJI_COUNT];
    private int emojiNumber = 0;

    public StoryAdapter() {
        clearEmojiTable();
    }

    protected StoryAdapter(Parcel in) {
        emojiNumber = in.readInt();
    }

    public static final Creator<StoryAdapter> CREATOR = new Creator<StoryAdapter>() {
        @Override
        public StoryAdapter createFromParcel(Parcel in) {
            return new StoryAdapter(in);
        }

        @Override
        public StoryAdapter[] newArray(int size) {
            return new StoryAdapter[size];
        }
    };

    public void addEmoji(int emojiId) {
        if (emojiNumber >= EmojiManager.MAX_EMOJI_COUNT) {
            throw new IllegalStateException("Table is full of emojis.");
        }
        emojiIds[emojiNumber++] = emojiId;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return EmojiManager.MAX_EMOJI_COUNT;
    }

    @Override
    public Object getItem(int i) {
        return emojiIds[i];
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        ImageView imageView;
        if (view == null) {
            // if it's not recycled, initialize some attributes
            Context context = viewGroup.getContext();
            imageView = new ImageView(context);
            imageView.setAdjustViewBounds(true);
            imageView.setPadding(5,5,5,5);
            imageView.setBackgroundColor(context.getResources().getColor(R.color.white));
            imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        } else {
            imageView = (ImageView) view;
        }

        //set image if resource is known
        if (emojiIds[position] != null){
            imageView.setImageResource(emojiIds[position]);
        }

        return imageView;
    }

    /**
     * Set all images to empty
     */
    public void clearEmojiTable(){
        emojiNumber = 0;
        for (int i = 0; i < emojiIds.length; i++) {
            emojiIds[i] = R.drawable.ic_unkown;
        }
        notifyDataSetChanged();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(emojiNumber);
    }
}
