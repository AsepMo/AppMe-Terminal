package com.lukegryga.smileup;

import android.graphics.Point;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Created by lgryga on 20.3.18.
 */

public class EmojiManager {
    public static final int MAX_EMOJI_COUNT = 10;
    private static final int DISTANCE_AROUND_EMOJI = 150;
    private static final int padding = 100;
    private static final Random random = new Random();

    /**
     * Generate x positions of emojis
     * - enable only two collision points for the future y position selection
     *
     * @param width of the layout
     * @return all x positions of emojis
     */
    private static int[] getXCoordinates(int width, int currentEmojiCount) {
        int maxDistance = (width-padding*2) / currentEmojiCount;
        int[] xCoordinates = new int[currentEmojiCount];
        for (int i = 0; i < currentEmojiCount; i++) {
            xCoordinates[i] = padding + i * maxDistance + random.nextInt(maxDistance);
        }
        return xCoordinates;
    }

    public static ArrayList<String> getEmojiNames() {
        ArrayList<String> names = new ArrayList<>(MAX_EMOJI_COUNT);
        for (int i = 0; i < MAX_EMOJI_COUNT; i++) {
            //Images start with emoji_000.png
            int randNum = 1 + random.nextInt(172); //172 - it is not too much !!! We must resize the pictures... DONE
            names.add(String.format("emoji_%03d", randNum));
        }
        return names;
    }


    public static Point[] getCoordinates(int width, int height, int currentEmojiCount) {
        if (currentEmojiCount == 0){
            return null;
        }
        int[] xCoordinates = getXCoordinates(width, currentEmojiCount);

        Point[] coordinates = new Point[currentEmojiCount];

        //Find first coordinates
        coordinates[0] = new Point(xCoordinates[0],
                padding + random.nextInt(height - padding * 2));

        //Check if we need more than one coordinate
        if (currentEmojiCount == 1){
            return coordinates;
        }

        //Find second coordinates
        try {
            coordinates[1] = new Point(xCoordinates[1],
                    findYCoordinate(height, coordinates[0].y, 0));
        } catch (IllegalStateException e) {
            e.printStackTrace();
            return getCoordinates(width, height, currentEmojiCount);
        }

        //Find the rest of coordinates
        for (int i = 2; i < currentEmojiCount; i++) {
            //only two collision are possible because of the way how x coordinates are selected
            // -> we are checking these two point for y collision
            try {
                coordinates[i] = new Point(xCoordinates[i],
                        findYCoordinate(height, coordinates[i - 1].y, coordinates[i - 2].y));
            } catch (IllegalStateException e) {
                e.printStackTrace();
                return getCoordinates(width, height, currentEmojiCount);
            }
        }
        return coordinates;
    }

    private static int findYCoordinate(int height, int restrictA, int restrictB) throws IllegalStateException {
        int randomY = padding + random.nextInt(height - 2 * padding);
        int suggestedY = randomY;
        final int move = 10;
        //first we try the values down
        while (suggestedY >= padding) {
            if (checkRestriction(suggestedY, restrictA) && checkRestriction(suggestedY, restrictB)) {
                return suggestedY;
            }
            suggestedY -= move;
        }
        //return to initial value
        suggestedY = randomY;
        //afterwards we try the values up
        while (suggestedY < height - padding) {
            if (checkRestriction(suggestedY, restrictA) && checkRestriction(suggestedY, restrictB)) {
                return suggestedY;
            }
            suggestedY += move;
        }

        //we had no success yet
        throw new IllegalStateException("There is not enough space for emoji");
    }

    private static boolean checkRestriction(int suggested, int restriction) {
        return suggested + DISTANCE_AROUND_EMOJI < restriction
                || suggested - DISTANCE_AROUND_EMOJI > restriction;
    }
}
