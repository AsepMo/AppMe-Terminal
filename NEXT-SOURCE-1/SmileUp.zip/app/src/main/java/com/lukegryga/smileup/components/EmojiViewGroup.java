package com.lukegryga.smileup.components;

import android.content.Context;
import android.graphics.Point;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.lukegryga.smileup.EmojiManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EmojiViewGroup extends ViewGroup {
    private List<MotionImageButton> emojis = new ArrayList<>(EmojiManager.MAX_EMOJI_COUNT);
    private ArrayList<String> emojiNames = new ArrayList<>(EmojiManager.MAX_EMOJI_COUNT);

    private OnClickListener emojiClickListener = null;

    public EmojiViewGroup(Context context) {
        this(context, null, 0);
    }

    public EmojiViewGroup(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public EmojiViewGroup(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }


    public void removeEmojiButton(MotionImageButton emojiButton) {
        if (!emojis.contains(emojiButton)) {
            Log.d("EmojiViewGroup", "pokus o odstraneni neexistujiciho tlacikta");
            return;
        }
        int index = emojis.indexOf(emojiButton);
        emojis.remove(index);
        emojiNames.remove(index);
        removeView(emojiButton);
    }


    public void setEmojiClickListener(OnClickListener emojiClickListener) {
        for (MotionImageButton emoji : emojis) {
            emoji.setOnClickListener(emojiClickListener);
        }
        this.emojiClickListener = emojiClickListener;
    }

    public void addEmojiButton(MotionImageButton emojiButton, boolean bindListeners) {
        if (emojiClickListener != null && bindListeners) {
            emojiButton.setOnClickListener(emojiClickListener);
        }
        emojis.add(emojiButton);
        emojiNames.add(getResources().getResourceEntryName(emojiButton.getDrawableId()));
        addView(emojiButton);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        if (changed) {
            Point[] coordinates = EmojiManager.getCoordinates(getWidth(), getHeight(), emojis.size());
            for (int i = 0; i < emojis.size(); i++) {
                MotionImageButton emoji = emojis.get(i);
                Point coord = coordinates[i];
                int imageSize = 150;
                emoji.layout(coord.x - imageSize/2, coord.y - imageSize/2,
                        coord.x + imageSize/2,coord.y + imageSize/2);
            }
        }
    }

    private void initEmoji(String emojiName) {
        int emojiID = getContext().getResources()
                .getIdentifier(emojiName, "drawable", getContext().getPackageName());
        MotionImageButton emoji = new MotionImageButton(getContext(), emojiID);
        emoji.setScaleType(ImageView.ScaleType.FIT_CENTER);
        emoji.setMoving(true);
        if (emojiClickListener != null) {
            emoji.setOnClickListener(emojiClickListener);
        }
        emojis.add(emoji);
        addView(emoji);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(widthMeasureSpec, heightMeasureSpec);
    }

    public void loadNewEmojis(){
        emojiNames = EmojiManager.getEmojiNames();
        for (int i = 0; i < EmojiManager.MAX_EMOJI_COUNT; i++) {
            initEmoji(emojiNames.get(i));
        }
    }

    public void restoreOldEmojis(ArrayList<String> emojiNames){
        this.emojiNames = emojiNames;
        for (int i = 0; i < emojiNames.size(); i++) {
            initEmoji(emojiNames.get(i));
        }
    }

    public ArrayList<String> getEmojiNames() {
        return emojiNames;
    }

    public List<MotionImageButton> getEmojis() {
        return Collections.unmodifiableList(emojis);
    }
}
