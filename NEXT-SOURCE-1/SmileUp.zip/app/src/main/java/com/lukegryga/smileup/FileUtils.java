package com.lukegryga.smileup;

import android.content.Context;
import android.util.LongSparseArray;

import com.lukegryga.smileup.components.TimeAndImageMark;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public final class FileUtils {
    public static final String initialName = "NameThatCantBeChosen";

    public static File[] getAllFiles(Context context) {
        return context.getFilesDir().listFiles();
    }

    public static File[] getTxtFiles(Context context){
        return context.getFilesDir().listFiles(new FileFilter() {
            @Override
            public boolean accept(File file) {
                return file.getName().endsWith(".txt") && !file.getName().equals(initialName);
            }
        });
    }

    /**
     * Get array of TimeAndImage marks for each txt file
     * : file format is
     * "time1,emoji_id1
     * time2,emoji_id2
     * ..."
     * @param context context
     * @return array of TimeAndImage
     */
    public static TimeAndImageMark[] getTimeAndImageMarks(Context context){
        File[] txtFiles = getTxtFiles(context);
        TimeAndImageMark[] timeAndImageMarks = new TimeAndImageMark[txtFiles.length];
        for (int i = 0; i < txtFiles.length; i++) {
            timeAndImageMarks[i] = parseTxtFile(txtFiles[i]);
        }
        return timeAndImageMarks;
    }

    public static TimeAndImageMark getTimeAndMark (Context context, String gameName) throws FileNotFoundException {
        File rootFile = context.getFilesDir();
        File timeAndMarkFile = new File(rootFile, gameName + ".txt");
        if (!timeAndMarkFile.exists()) {
            throw new FileNotFoundException(gameName + ".txt doesn't found.");
        }
        return parseTxtFile(timeAndMarkFile);
    }

    public static File getAudioFile(Context context, String gameName) throws FileNotFoundException {
        File rootFile = context.getFilesDir();
        File audioFile = new File(rootFile, gameName + ".mp3");
        if (!audioFile.exists()) {
            throw new FileNotFoundException(gameName + ".mp3 doesn't found.");
        }
        return audioFile;
    }

    /**
     * Parse text file
     * : file format is
     * "time1,emoji_id1
     * time2,emoji_id2
     * ..."
     * @param txtFile to be parsed
     * @return timeAndImageMarks
     */
    private static TimeAndImageMark parseTxtFile(File txtFile) {
        List<Long> seconds = new ArrayList<>();
        List<Integer> imageIds = new ArrayList<>();

        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(txtFile));
            String line;
            while ((line = br.readLine()) != null){
                String[] dividedLine = line.split(",");
                seconds.add(Long.valueOf(dividedLine[0]));
                imageIds.add(Integer.valueOf(dividedLine[1]));
            }

        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException ignored) {}
            }
        }
        String fileName = txtFile.getName().substring(0, txtFile.getName().lastIndexOf('.'));
        return new TimeAndImageMark(fileName, seconds, imageIds);
    }

    /**
     * Save audio and timeMarks in selectedName.mp3 and selectedName.txt format
     *
     * timeMarks format is
     *  "time1,emoji_id1
     *  time2,emoji_id2
     *  ..."
     *  @param context context
     * @param selectedName where should be data saved
     * @param timeMarks
     */
    public static boolean saveData(Context context, String selectedName,
                                   LongSparseArray<Integer> timeMarks) {
        File filesDir = context.getFilesDir();
        if (!isValidFileName(filesDir, selectedName)){
            //file name is not valid
            return false;
        }

        //Rename file to the selected name, initial file will be overwritten during the next recording
        File audioFile = new File(filesDir, FileUtils.initialName);
        if (!audioFile.renameTo(new File(filesDir, selectedName.concat(".mp3")))) {
            return false;
        }

        File timeMarksFile = new File(filesDir, selectedName.concat(".txt"));
        BufferedWriter bw = null;
        try {
            bw = new BufferedWriter(new FileWriter(timeMarksFile));
            for (int i = 0; i < timeMarks.size(); i++) {
                bw.append(String.valueOf(timeMarks.keyAt(i)))
                .append(",")
                .append(String.valueOf(timeMarks.valueAt(i)))
                .append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        } finally {
            if (bw != null) {
                try {
                    bw.close();
                } catch (IOException ignored) {}
            }
        }
        return true;
    }

    /**
     * Check restrictions on file name
     *
     * @param selectedName to be checked
     * @return if file name is not initialName, "" or already existing name of an record
     */
    private static boolean isValidFileName(File filesDir, String selectedName) {
        return !selectedName.equals("") && !selectedName.equals(initialName)
                && !new File(filesDir, selectedName.concat(".txt")).exists();
    }
}
