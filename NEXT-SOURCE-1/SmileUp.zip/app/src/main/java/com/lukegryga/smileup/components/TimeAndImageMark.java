package com.lukegryga.smileup.components;

import android.media.Image;

import java.util.List;

public class TimeAndImageMark {
    private String name; //name of the story
    private List<Long> seconds;
    private List<Integer> imageIds;

    public TimeAndImageMark(String name, List<Long> seconds, List<Integer> imageIds) {
        this.name = name;
        this.seconds = seconds;
        this.imageIds = imageIds;
    }

    public List<Long> getSeconds() {
        return seconds;
    }

    public List<Integer> getImageIds() {
        return imageIds;
    }

    public String getName() {
        return name;
    }
}
