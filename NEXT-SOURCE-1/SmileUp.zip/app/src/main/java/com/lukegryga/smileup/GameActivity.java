package com.lukegryga.smileup;

import android.app.Dialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.media.MediaRecorder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.LongSparseArray;
import android.view.View;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import com.lukegryga.smileup.adapters.StoryAdapter;
import com.lukegryga.smileup.components.EmojiViewGroup;
import com.lukegryga.smileup.components.MotionImageButton;

import java.io.IOException;
import java.util.ArrayList;

public class GameActivity extends AppCompatActivity implements View.OnClickListener{

    private StoryAdapter storyAdapter;
    private EmojiViewGroup emojiArea;
    private String initialPath;

    private final LongSparseArray<Integer> timeMarks = new LongSparseArray<>(EmojiManager.MAX_EMOJI_COUNT);
    private long startTime = -1;
    private static final int imageSize = 150;

    private static MediaRecorder mediaRecorder = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        GridView storyTable = findViewById(R.id.gv_story_table);
        emojiArea = findViewById(R.id.vg_emoji_area);
        if (savedInstanceState != null){
            storyAdapter = (StoryAdapter) savedInstanceState.getParcelable("storyAdapter");
            emojiArea.restoreOldEmojis(savedInstanceState.getStringArrayList("emojiNames"));
        } else {
            storyAdapter = new StoryAdapter();
            emojiArea.loadNewEmojis();
        }
        //handle landscape orientation
        if (getResources().getConfiguration().orientation ==
                Configuration.ORIENTATION_LANDSCAPE) {
            storyTable.setNumColumns(EmojiManager.MAX_EMOJI_COUNT); //initial is 5
        }
        storyTable.setAdapter(storyAdapter);
        initialPath = getFilesDir().getAbsolutePath().concat("/").concat(FileUtils.initialName);
        emojiArea.setEmojiClickListener(this);
        initRecorder();

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        //TODO save imageMarks, MediaPlayer
        outState.putParcelable("storyAdapter", storyAdapter);
        outState.putStringArrayList("emojiNames", (ArrayList<String>) emojiArea.getEmojiNames());
    }

    public void onClick(View view) {
        MotionImageButton emojiButton = (MotionImageButton) view;
        storyAdapter.addEmoji(emojiButton.getDrawableId());
        emojiArea.removeEmojiButton(emojiButton);
        addEmojiWithTime(emojiButton.getDrawableId());

        if (emojiArea.getEmojis().size() == 0) {
            MotionImageButton emoji = new MotionImageButton(emojiArea.getContext(), R.drawable.emoji_end);
            emoji.setScaleType(ImageView.ScaleType.FIT_CENTER);
            emoji.setMoving(true);
            emoji.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    endGame(view);
                }
            });
            //TODO přepočítat na dp ? velikost obrázků není konzistentní
            emoji.layout(emojiArea.getWidth() / 2 - imageSize / 2, emojiArea.getHeight() / 2 - imageSize / 2,
                    emojiArea.getWidth() / 2 + imageSize / 2, emojiArea.getHeight() / 2);
            emojiArea.addEmojiButton(emoji, false);
        }
    }

    private void initRecorder() {
        try {
            mediaRecorder = new MediaRecorder();
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            mediaRecorder.setOutputFile(initialPath);
            mediaRecorder.prepare();
        } catch (IOException | RuntimeException e) {
            Toast toast = Toast.makeText(this, "Audio won't be captured", Toast.LENGTH_SHORT);
            toast.show();
            Log.e("AudioRecorder", e.toString());
        }
    }

    private void addEmojiWithTime(int drawableId) {
        if (startTime == -1) {
            startTime = System.currentTimeMillis();
            mediaRecorder.start();
        }
        long actTime = System.currentTimeMillis();
        timeMarks.put(actTime - startTime, drawableId);
    }

    private void endGame(View v) {
        emojiArea.removeEmojiButton((MotionImageButton) v);
        mediaRecorder.stop();
        mediaRecorder.release();
        mediaRecorder = null;
        callSaveDialog();
    }


    /**
     * Call save dialog and save discard data depending in user selection
     */
    private void callSaveDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.save_dialog);
        dialog.setTitle(R.string.save_name_label);
        dialog.setCancelable(false);

        final EditText name = dialog.findViewById(R.id.et_save_name);
        dialog.show();

        //on save
        dialog.findViewById(R.id.bt_save_game).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String selectedName = name.getText().toString();
                dialog.findViewById(R.id.tv_save_error).setVisibility(View.INVISIBLE);
                if (!FileUtils.saveData(getBaseContext(), selectedName, timeMarks)){
                    dialog.findViewById(R.id.tv_save_error).setVisibility(View.VISIBLE);
                    return;
                }
                dialog.cancel();
                startNewGame();


            }
        });

        //on discard
        dialog.findViewById(R.id.bt_discard_game).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.cancel();
                        startNewGame();
                    }
                }
        );
    }

    /**
     * Refresh all states
     */
    private void startNewGame() {
        startActivity(new Intent(this, GameActivity.class));
    }

}
