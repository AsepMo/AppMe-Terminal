package com.lukegryga.smileup.components;

import android.content.Context;
import android.graphics.Point;
import android.support.annotation.NonNull;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.Interpolator;

import java.util.Random;


public class MotionImageButton extends android.support.v7.widget.AppCompatImageButton {

    private final Random RANDOM = new Random();

    private int motionRange = 20;
    private int motionAngle = 10;
    private int speed = 50;

    private final int drawableId;

    private boolean moving = false;

    //Constructors
    public MotionImageButton(Context context, int drawableId) {
        super(context);
        this.drawableId = drawableId;
        setBackgroundResource(drawableId);
    }

    public MotionImageButton(Context context, AttributeSet attrs, int drawableId) {
        super(context, attrs);
        this.drawableId = drawableId;
        setBackgroundResource(drawableId);
    }

    public MotionImageButton(Context context, AttributeSet attrs, int defStyleAttr, int drawableId) {
        super(context, attrs, defStyleAttr);
        this.drawableId = drawableId;
        setBackgroundResource(drawableId);
        //setId(View.generateViewId()); //FIXME - supported API 17 - uncomment
    }

    //Setters and Getters


    public int getDrawableId() {
        return drawableId;
    }

    public MotionImageButton setSpeed(int speed) {
        this.speed = speed;
        return this;
    }

    public int getSpeed() {
        return this.speed;
    }

    public MotionImageButton setRotation(int angle) {
        this.motionAngle = angle;
        return this;
    }

    public int getMotionAngle() {
        return this.motionAngle;
    }

    public MotionImageButton setRange(int range) {
        this.motionRange = range;
        return this;
    }

    public int getMotionRange() {
        return this.motionRange;
    }

    public void setMoving(boolean moving) {
        this.moving = moving;
        if (moving) {
            moving();
        }
    }

    private void moving() {
        if (!moving) { return; }

        Point newPos = newRandomPosition();
        this.animate().translationX(newPos.x).translationY(newPos.y)
                .rotation(newRandomAngle())
                .setDuration(calculateDuration(newPos))
                .setInterpolator(new Interpolator() {
                    @Override
                    public float getInterpolation(float v) {
                        return v;
                    }
                })
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        moving();
                    }
                });
    }

    private int calculateDuration(Point point) {
        double xShift = this.getTranslationX() - point.x;
        double yShift = this.getTranslationY() - point.y;
        double squares = Math.pow(xShift, 2) + Math.pow(yShift, 2);
        double distance = Math.sqrt(squares);
        return Double.valueOf(distance).intValue() * (4000 / speed);
    }

    @NonNull
    private Point newRandomPosition() {
        return new Point(RANDOM.nextInt(motionRange) - motionRange /2,
                RANDOM.nextInt(motionRange) - motionRange /2);
    }

    private float newRandomAngle() {
        return RANDOM.nextFloat() * motionAngle - motionAngle / 2;
    }
}
