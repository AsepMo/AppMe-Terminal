package com.lukegryga.smileup;

import android.app.job.JobScheduler;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import com.lukegryga.smileup.adapters.StoryAdapter;
import com.lukegryga.smileup.components.MotionImageButton;
import com.lukegryga.smileup.components.TimeAndImageMark;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class RecapActivity extends AppCompatActivity {

    public static final String EXTRA_KEY_GAMENAME = "extra_gamename";

    private String gameName;
    private TimeAndImageMark timeAndImageMarks;
    MediaPlayer mPlayer;

    private StoryAdapter gameOverviewAdapter;

    private PresentEmojiHandler presentEmojiHandler;
    private Future<?>[] presentationSteps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //init saved game
        gameName = getIntent().getStringExtra(EXTRA_KEY_GAMENAME);
        try {
            timeAndImageMarks = FileUtils.getTimeAndMark(this, gameName);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            finish();
        }

        setContentView(R.layout.activity_recap);
        initOverview();
        ImageView actEmoji = findViewById(R.id.mib_main_stage);
        presentEmojiHandler = new PresentEmojiHandler(Looper.getMainLooper(), actEmoji);
    }

    @Override
    protected void onStart() {
        super.onStart();
        initMedia();
        runPresentation();
        if (mPlayer != null) {
            mPlayer.start();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        stopPresentation();
        if (mPlayer != null) {
            mPlayer.stop();
            mPlayer.release();
            mPlayer = null;
        }
    }

    private void initMedia() {
        mPlayer = new MediaPlayer();
        File audioFile = null;
        try {
            audioFile = FileUtils.getAudioFile(this, gameName);
            mPlayer.setDataSource(audioFile.getPath());
            mPlayer.prepare();
        } catch (Exception e) {
            e.printStackTrace();
            mPlayer.release();
            Toast.makeText(this, "Audio cannot be loaded.",
                    Toast.LENGTH_SHORT).show();
            mPlayer = null;
            return;
        }
    }

    private void initOverview() {
        GridView gameOverview = findViewById(R.id.gv_emoji_game_overview);
        if (getResources().getConfiguration().orientation ==
                Configuration.ORIENTATION_LANDSCAPE) {
            gameOverview.setNumColumns(10); //initial is 5
        }
        gameOverviewAdapter = new StoryAdapter();
        for(int imgId : timeAndImageMarks.getImageIds()) {
            gameOverviewAdapter.addEmoji(imgId);
        }
        gameOverview.setAdapter(gameOverviewAdapter);
    }

    private void runPresentation() {
        if (presentationSteps != null) {
            return;
        }
        int emojiCount = timeAndImageMarks.getImageIds().size();
        ScheduledExecutorService scheduledExecutorService =
                new ScheduledThreadPoolExecutor(1);
        presentationSteps = new Future<?>[emojiCount];
        for (int i = 0; i < emojiCount; i++) {
            PresentEmojiTask task = new PresentEmojiTask(presentEmojiHandler, this,
                    timeAndImageMarks.getImageIds().get(i));

            presentationSteps[i] = scheduledExecutorService.schedule(task,
                    timeAndImageMarks.getSeconds().get(i), TimeUnit.MILLISECONDS);
        }
    }

    private void stopPresentation() {
        if (presentationSteps == null) {
            return;
        }
        for (Future<?> future : presentationSteps) {
            future.cancel(true);
        }
        presentationSteps = null;
    }

    /**
     * This class is used to notify PresentEmojiHandler.
     */
    private class PresentEmojiTask implements Runnable {

        PresentEmojiHandler presentEmojiHandler;
        Drawable emojiDrawable;
        Context context;

        public PresentEmojiTask(PresentEmojiHandler presentEmojiHandler, Context context, int emojiDrawableId) {
            this.presentEmojiHandler = presentEmojiHandler;
            this.context = context;
            emojiDrawable = context.getResources().getDrawable(emojiDrawableId);
        }

        @Override
        public void run() {
            presentEmojiHandler.obtainMessage(0, emojiDrawable).sendToTarget();
            Log.d("ttt", "tick");
        }
    }


    /**
     * This class is used to set ImageView source from another thread.
     * This handler is supposed to run in UI thread.
     */
    private class PresentEmojiHandler extends Handler {

        private final ImageView emojiView;

        public PresentEmojiHandler(Looper looper, ImageView emojiView) {
            super(looper);
            this.emojiView = emojiView;
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            Drawable emoji = (Drawable)msg.obj;
            emojiView.setImageDrawable(emoji);
        }
    }
}
