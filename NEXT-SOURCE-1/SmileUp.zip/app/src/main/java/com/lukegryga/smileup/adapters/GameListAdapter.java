package com.lukegryga.smileup.adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.lukegryga.smileup.FileUtils;
import com.lukegryga.smileup.R;
import com.lukegryga.smileup.RecapActivity;
import com.lukegryga.smileup.components.TimeAndImageMark;

import java.util.List;

public class GameListAdapter extends RecyclerView.Adapter<GameListAdapter.GameViewHolder>{

    private final Context context;
    private TimeAndImageMark[] timeAndImageMarks;

    public GameListAdapter(Context context) {
        this.context = context;
        timeAndImageMarks = FileUtils.getTimeAndImageMarks(context);
    }

    @Override
    public GameViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.game_list_item, parent, false);
        return new GameViewHolder(view);
    }

    @Override
    public void onBindViewHolder(GameViewHolder holder, int position) {
        holder.name.setText(timeAndImageMarks[position].getName());
        holder.images.removeAllViews();
        List<Integer> images = timeAndImageMarks[position].getImageIds();
        for (int i = 0; i < images.size(); i++) {
            ImageView view = new ImageView(context);
            view.setImageResource(images.get(i));
            view.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));
            view.setPadding(10,10,10,10);
            view.setAdjustViewBounds(true);
            holder.images.addView(view);
        }
    }

    @Override
    public int getItemCount() {
        return timeAndImageMarks.length;
    }

    public void refresh() {
        timeAndImageMarks = FileUtils.getTimeAndImageMarks(context);
        notifyDataSetChanged();
    }

    class GameViewHolder extends RecyclerView.ViewHolder{
        TextView name;
        LinearLayout images;

        public GameViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.tv_game_list_name);
            images = itemView.findViewById(R.id.ll_game_list_story_images);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(context, RecapActivity.class);
                    intent.putExtra(RecapActivity.EXTRA_KEY_GAMENAME, name.getText());
                    context.startActivity(intent);
                }
            });
        }
    }
}
