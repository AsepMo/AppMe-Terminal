package com.github.gallery.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import com.github.gallery.R;

public class LicenseActivity extends SimpleActivity implements View.OnClickListener
{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_license);
        findViewById(R.id.license_butterknife_title).setOnClickListener(this);
        findViewById(R.id.license_photoview_title).setOnClickListener(this);
        
    }

    @Override
    public void onClick(View v)
    {
        switch(v.getId()){
            case R.id.license_butterknife_title:
                butterKnifeClicked();
                break;
            case R.id.license_photoview_title:
                photoViewClicked();
                break;
        }
    }
    
    
    public void butterKnifeClicked() {
        openUrl(R.string.butterknife_url);
    }

    
    public void photoViewClicked() {
        openUrl(R.string.photoview_url);
    }

    private void openUrl(int id) {
        final String url = getResources().getString(id);
        final Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(browserIntent);
    }
}
